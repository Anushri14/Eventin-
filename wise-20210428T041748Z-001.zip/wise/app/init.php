<?php
session_start();
$_SESSION['user_id']=4;
$db = new PDO('mysql:dbname=todo;host=localhost','root','');
if(!isset($_SESSION['user_id'])) {
	die('YOU ARE NOT SIGNED IN  ');
}
?>